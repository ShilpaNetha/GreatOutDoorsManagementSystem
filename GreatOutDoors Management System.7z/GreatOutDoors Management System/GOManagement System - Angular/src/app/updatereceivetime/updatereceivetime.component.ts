import { Component, OnInit } from '@angular/core';
import { ShelftimereportService, Shelftimereport } from '../Shelftimereport.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updatereceivetime',
  templateUrl: './updatereceivetime.component.html',
  styleUrls: ['./updatereceivetime.component.css']
})
export class UpdatereceivetimeComponent implements OnInit 
{
  user : Shelftimereport = new Shelftimereport(0,0,"",0,"","",new(Date),new(Date),"");
  
  constructor(private shelftimereportservice : ShelftimereportService, private router: Router) { }

  ngOnInit() {
  }

  addproductdetails():void
  {
    this.shelftimereportservice.addproductdetails(this.user)
    .subscribe( data => { alert("Product details has been updates succesfully");});
  }
}
