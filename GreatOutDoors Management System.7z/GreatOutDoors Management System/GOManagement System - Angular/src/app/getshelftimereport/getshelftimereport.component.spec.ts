import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetshelftimereportComponent } from './getshelftimereport.component';

describe('GetshelftimereportComponent', () => {
  let component: GetshelftimereportComponent;
  let fixture: ComponentFixture<GetshelftimereportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetshelftimereportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetshelftimereportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
