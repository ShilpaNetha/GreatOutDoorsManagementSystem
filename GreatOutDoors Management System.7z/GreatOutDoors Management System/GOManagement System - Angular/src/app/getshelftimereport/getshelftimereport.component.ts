import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Shelftimereport, ShelftimereportService } from '../Shelftimereport.service';

@Component({
  selector: 'app-getshelftimereport',
  templateUrl: './getshelftimereport.component.html',
  styleUrls: ['./getshelftimereport.component.css']
})
export class GetshelftimereportComponent implements OnInit 
{
  entries : Shelftimereport[];
  entry : Shelftimereport;

  constructor(private shelftimereportservice : ShelftimereportService, private router: Router) { }

  ngOnInit()
  {
    this.shelftimereportservice.getshelftimereport().subscribe(
      (entries)=>{
          this.entries=entries.retailerList;
          console.log(entries.retailerList)

        });
  }

}
