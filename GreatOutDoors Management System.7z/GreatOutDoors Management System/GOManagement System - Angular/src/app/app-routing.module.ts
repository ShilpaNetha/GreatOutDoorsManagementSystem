import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GetretailerlistComponent } from './getretailerlist/getretailerlist.component';
import { GetshelftimereportComponent } from './getshelftimereport/getshelftimereport.component';
import { UpdatereceivetimeComponent } from './updatereceivetime/updatereceivetime.component';



const routes: Routes = [
  {path:'app-updatereceivetime',component:UpdatereceivetimeComponent},
  {path:'app-getretailerlist',component:GetretailerlistComponent},
  {path:'app-getshelftimereport',component:GetshelftimereportComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
