import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Shelftimereport, ShelftimereportService } from '../Shelftimereport.service';

@Component({
  selector: 'app-getretailerlist',
  templateUrl: './getretailerlist.component.html',
  styleUrls: ['./getretailerlist.component.css']
})
export class GetretailerlistComponent implements OnInit 
{
  entries : Shelftimereport[];
  entry : Shelftimereport;

  constructor(private shelftimereportservice : ShelftimereportService, private router: Router) { }

  ngOnInit()
  {
    this.shelftimereportservice.getretailerlist().subscribe(
      (entries)=>{
          this.entries=entries.retailerList;
          console.log(entries.retailerList)

        });
  }
}
