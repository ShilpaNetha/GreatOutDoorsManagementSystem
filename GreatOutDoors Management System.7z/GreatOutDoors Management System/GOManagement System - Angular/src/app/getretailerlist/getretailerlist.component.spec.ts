import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetretailerlistComponent } from './getretailerlist.component';

describe('GetretailerlistComponent', () => {
  let component: GetretailerlistComponent;
  let fixture: ComponentFixture<GetretailerlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetretailerlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetretailerlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
