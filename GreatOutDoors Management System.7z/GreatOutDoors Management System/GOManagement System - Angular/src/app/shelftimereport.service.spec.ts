import { TestBed } from '@angular/core/testing';

import { ShelftimereportService } from './shelftimereport.service';

describe('ShelftimereportService', () => {
  let service: ShelftimereportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ShelftimereportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
