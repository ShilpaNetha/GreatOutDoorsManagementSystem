import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ShelftimereportService 
{
  shelftimereport : Shelftimereport[];

  constructor(private httpService: HttpClient) 
    { }

    public addproductdetails(shelftimereport):Observable<Shelftimereport> 
    {
      console.log(shelftimereport);
      return this.httpService.post<Shelftimereport>("http://localhost:8090/shelftimereport/add/details", shelftimereport);
    }

    getretailerlist()
    {
      return this.httpService.get<RetailerList>("http://localhost:8090/shelftimereport/list/retailer");
    } 

    getshelftimereport()
    {
      return this.httpService.get<RetailerList>("http://localhost:8090/shelftimereport/shelftimeperiod/");
    }

}
export class Shelftimereport
{
  constructor(public productUniqueId : number, public retailerid : number, public retailerName : String,
    public productCategoryNumber : number, public productCategoryName : String, 
    public productName : String, public productRecieveTimeStamp : Date,
    public productSaleTimeStamp : Date, public shelfTimePeriod : String) 
  { }
}

export class RetailerList
{
  public retailerList : Shelftimereport[];
}