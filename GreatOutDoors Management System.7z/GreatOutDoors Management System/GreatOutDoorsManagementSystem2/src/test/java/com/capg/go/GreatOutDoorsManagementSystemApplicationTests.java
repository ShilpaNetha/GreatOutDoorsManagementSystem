package com.capg.go;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.capg.go.dto.ShelfTimeReportDTO;
import com.capg.go.repository.IShelfTimeReportRepo;
import com.capg.go.service.IShelfTimeReportService;
@RunWith(SpringRunner.class)
@SpringBootTest
class GreatOutdoorsManagementSystemApplicationTests 
{
	@Autowired
	IShelfTimeReportService service;
	
	@MockBean
	IShelfTimeReportRepo repo;
	
	@Test
	public void addproductdetails() 
	{
		ShelfTimeReportDTO bean = new ShelfTimeReportDTO();
		
		bean.setProductUniqueId(2300);
		bean.setRetailerid(11);
		bean.setRetailerName("ShilpaNetha");
		bean.setProductCategoryNumber((byte) 2);
		bean.setProductCategoryName("Personalised");
		bean.setProductName("LapTop");
		
		Mockito.when(repo.save(bean)).thenReturn(bean);
		assertEquals(bean,service.addproductdetails(bean));

	}

	@Test
	public void getRetailerList() 
	{
		ShelfTimeReportDTO bean1 = new ShelfTimeReportDTO();
		
        bean1.setProductUniqueId(2300);
		bean1.setRetailerid(11);
		bean1.setRetailerName("ShilpaNetha");
		bean1.setProductCategoryNumber((byte) 2);
		bean1.setProductCategoryName("Personalised");
		bean1.setProductName("LapTop");
		
		ShelfTimeReportDTO bean2 = new ShelfTimeReportDTO();
		
		bean2.setProductUniqueId(2300);
		bean2.setRetailerid(11);
		bean2.setRetailerName("ShilpaNetha");
		bean2.setProductCategoryNumber((byte) 2);
		bean2.setProductCategoryName("Personalised");
		bean2.setProductName("LapTop");
		
		List<ShelfTimeReportDTO> retailerList = new ArrayList<>();
		
		retailerList.add(bean1);
		retailerList.add(bean2);

		Mockito.when(repo.findAll()).thenReturn(retailerList);
	    //assertThat(service.getRetailerList()).isEqualTo(retailerList);
		assertEquals(retailerList.size(),2);	 
	}

}
