package com.capg.go.selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WrapperMethods 
{
	static WebDriver driver;
    
    public void insertapp(String url)
    {
    	WebDriverManager.edgedriver().setup();
        //driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get(url);
    }
    
	public void enterbyxapth(String val2, String name2)
	{
	        driver.findElement(By.xpath(val2)).sendKeys(name2);	
	}
    
        
    public void clickbyxpath(String val1) {
        driver.findElement(By.xpath(val1)).click();
    }
    
    
    public void closeapp() {
        driver.close();
    }
    
}
