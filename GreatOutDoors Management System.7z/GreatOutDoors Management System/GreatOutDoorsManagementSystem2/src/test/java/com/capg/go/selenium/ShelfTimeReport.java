package com.capg.go.selenium;

import org.openqa.selenium.Keys;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ShelfTimeReport 
{
	WrapperMethods wrapperMethods=new WrapperMethods();
	
	@BeforeTest
	public void launchApp() {
	  wrapperMethods.insertapp("http://localhost:4200/");	
	}
	
	@BeforeMethod
	public void addProductDetails() 
	{
	  wrapperMethods.clickbyxpath("/html/body/app-root/div/nav/ul/li[1]/a");
	  wrapperMethods.enterbyxapth("//*[@id=\"productUniqueId\"]","345"+Keys.ENTER);
	  wrapperMethods.enterbyxapth("//*[@id=\"retailerid\"]","2"+Keys.ENTER);
	  wrapperMethods.enterbyxapth("//*[@id=\"retailerName\"]","shilpaaa"+Keys.ENTER);
	  wrapperMethods.enterbyxapth("//*[@id=\"productCategoryNumber\"]","1"+Keys.ENTER);
	  wrapperMethods.enterbyxapth("//*[@id=\"productCategoryName\"]","personal"+Keys.ENTER);
	  wrapperMethods.enterbyxapth("//*[@id=\"productName\"]","LapTop"+Keys.ENTER);
	  wrapperMethods.enterbyxapth("//*[@id=\"productRecieveTimeStamp\"]","23-05-2020"+Keys.ENTER);
	  wrapperMethods.enterbyxapth("//*[@id=\"productSaleTimeStamp\"]","15-09-2020"+Keys.ENTER);	  
   	}
	
	@Test
	public void admin() {
		wrapperMethods.clickbyxpath("/html/body/app-root/app-updatereceivetime/div/form/input"); 
	}
	
	@AfterMethod
	public void closeApp() {
		System.out.println(wrapperMethods.driver.getTitle());
	}
	
	@AfterTest
	public void tearDown() {
		wrapperMethods.closeapp();
	}

}
