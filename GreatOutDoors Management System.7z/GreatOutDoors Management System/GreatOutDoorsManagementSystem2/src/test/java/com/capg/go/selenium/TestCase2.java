package com.capg.go.selenium;

import org.openqa.selenium.Keys;

public class TestCase2 
{
	public static void main(String[] args) 
	{
		
		 WrapperMethods wrapper = new WrapperMethods();
		 
		 wrapper.insertapp("http://localhost:4200/");
		 wrapper.clickbyxpath("/html/body/app-root/div/nav/ul/li[1]/a");
		 wrapper.enterbyxapth("//*[@id=\"productUniqueId\"]","345"+Keys.ENTER);
		 wrapper.enterbyxapth("//*[@id=\"retailerid\"]","2"+Keys.ENTER);
	     wrapper.enterbyxapth("//*[@id=\"retailerName\"]","shilpaaa"+Keys.ENTER);
	     wrapper.enterbyxapth("//*[@id=\"productCategoryNumber\"]","1"+Keys.ENTER);
	     wrapper.enterbyxapth("//*[@id=\"productCategoryName\"]","personal"+Keys.ENTER);
         wrapper.enterbyxapth("//*[@id=\"productName\"]","LapTop"+Keys.ENTER);
	     wrapper.enterbyxapth("//*[@id=\"productRecieveTimeStamp\"]","23-05-2020"+Keys.ENTER);
		 wrapper.enterbyxapth("//*[@id=\"productSaleTimeStamp\"]","15-09-2020"+Keys.ENTER);	
	     wrapper.clickbyxpath("/html/body/app-root/app-updatereceivetime/div/form/input");
    }
}
