package com.capg.go.dto;

import java.util.List;

import javax.persistence.Entity;

public class RetailerList 
{
	private List<ShelfTimeReportDTO>  retailerList;

	public List<ShelfTimeReportDTO> getRetailerList() {
		return retailerList;
	}

	public void setRetailerList(List<ShelfTimeReportDTO> retailerList) {
		this.retailerList = retailerList;
	}
	
	public RetailerList() 
	{
		super();
	}

	public RetailerList(List<ShelfTimeReportDTO> retailerList) {
		super();
		this.retailerList = retailerList;
	}

}
