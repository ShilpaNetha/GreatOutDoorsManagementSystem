package com.capg.go.service;

import com.capg.go.dto.RetailerList;
import com.capg.go.dto.ShelfTimeReportDTO;

public interface IShelfTimeReportService {

	ShelfTimeReportDTO addproductdetails(ShelfTimeReportDTO dto);

	RetailerList getretailerlist();

	RetailerList getshelftimereport();

}
