package com.capg.go.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.capg.go.dto.RetailerList;
import com.capg.go.dto.ShelfTimeReportDTO;
import com.capg.go.service.ShelfTimeReportServiceImpl;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/shelftimereport")
public class ShelfTimeReportController 
{
	@Autowired
	ShelfTimeReportServiceImpl service;
	
	@PostMapping("/add/details")
	public ResponseEntity<ShelfTimeReportDTO> addproductdetails(@RequestBody ShelfTimeReportDTO dto)
	{
		try 
		{
			dto = service.addproductdetails(dto);
			return new ResponseEntity<ShelfTimeReportDTO>(dto,HttpStatus.OK);
		} 
		catch (Exception e) 
		{
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Error updating recieve time details", e);
		}
		
	}
	
	@GetMapping("/list/retailer")
	public RetailerList getretailerlist()
	{
		try 
		{
			return service.getretailerlist();
		} 
		catch (Exception e) 
		{
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Error getting the retailer list", e);
		}
			
	}
	
	@GetMapping("/shelftimeperiod")
	public RetailerList getshelftimereport()
	{
		try 
		{
			RetailerList b = service.getshelftimereport(); 
			
			return b;
			
			//return "ShelfTimeReport of retailerId : "+b.getRetailerid()+ " and the product unique id is "+b.getProductUniqueId()+
					                    //  " and the shelftime period of the product is " +b.getShelfTimePeriod();
		} 
		catch (Exception e) 
		{
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Entered retailerId does not exists", e);
		}
			
	}

}

