/********************************************************
 -Author                : Shilpa Netha
 -Created/Modified Date : 21/09/2020
 -Description           : ShelfTimeReportServiceImpl 
 						  implements services for 
 						  IShelfTimeReportService for 
 						  Shelf Time Report management 
 						  system
*********************************************************/
package com.capg.go.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.capg.go.dto.RetailerList;
import com.capg.go.dto.ShelfTimeReportDTO;
import com.capg.go.repository.IShelfTimeReportRepo;

@Service
public class ShelfTimeReportServiceImpl implements IShelfTimeReportService
{
	@Autowired(required = true)
	IShelfTimeReportRepo repo;
	
	@Autowired
	RestTemplate restTemplate;
	
	
	/***************************************************
	 -FunctionName          : addproductdetails()
	 -Return Type           : ShelfTimeReportDTO
	 -Author				: Shilpa Netha
	 -Creation Date			: 21/09/2020
	 -Description			: To add some products receive 
	                          time details into database 
	*****************************************************/
	@Override
	public ShelfTimeReportDTO addproductdetails(ShelfTimeReportDTO dto) 
	{
		return repo.save(dto);
	}

	
	/***************************************************
	 -FunctionName          : getretailerlist()
	 -Return Type           : RetailerList
	 -Author				: Shilpa Netha
	 -Creation Date			: 21/09/2020
	 -Description			: To display all the list of 
	                          retailer 
	*****************************************************/
	
	@Override
	public RetailerList getretailerlist() 
	{
		return new RetailerList(repo.findAll());
	}

	
	/***************************************************
	 -FunctionName          : getShelfTimeReport()
	 -Return Type           : ShelfTimeReportDTO
	 -Author				: Shilpa Netha
	 -Creation Date			: 21/09/2020
	 -Description			: To calculate the shelf time 
	                          period of each product by 
	                          entering the retailerid 
	*****************************************************/
	@Override
	public RetailerList getshelftimereport() 
	{
		return new RetailerList(repo.findAll());
	}

}