package com.capg.go.dto;

import java.time.LocalDate;
import java.time.Period;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="shelftimereport")
public class ShelfTimeReportDTO 
{
	@Id
	private int productUniqueId;
	private int retailerid;
	private String retailerName;
	private byte productCategoryNumber;
	private String productCategoryName;
	private String productName;
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate productRecieveTimeStamp;
	private LocalDate productSaleTimeStamp;
	private Period shelfTimePeriod;
	
	public int getRetailerid() {
		return retailerid;
	}
	public void setRetailerid(int retailerid) {
		this.retailerid = retailerid;
	}
	public String getRetailerName() {
		return retailerName;
	}
	public void setRetailerName(String retailerName) {
		this.retailerName = retailerName;
	}
	public byte getProductCategoryNumber() {
		return productCategoryNumber;
	}
	public void setProductCategoryNumber(byte productCategoryNumber) {
		this.productCategoryNumber = productCategoryNumber;
	}
	public String getProductCategoryName() {
		return productCategoryName;
	}
	public void setProductCategoryName(String productCategoryName) {
		this.productCategoryName = productCategoryName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductUniqueId() {
		return productUniqueId;
	}
	public void setProductUniqueId(int productUniqueId) {
		this.productUniqueId = productUniqueId;
	}
	public LocalDate getProductRecieveTimeStamp() {
		return productRecieveTimeStamp;
	}
	public void setProductRecieveTimeStamp(LocalDate productRecieveTimeStamp) {
		this.productRecieveTimeStamp = productRecieveTimeStamp;
	}
	public LocalDate getProductSaleTimeStamp() {
		return productSaleTimeStamp;
	}
	public void setProductSaleTimeStamp(LocalDate productSaleTimeStamp) {
		this.productSaleTimeStamp = productSaleTimeStamp;
	}
	
	
	public Period getShelfTimePeriod() {
		return Period.between(productRecieveTimeStamp, productSaleTimeStamp);
	}
	public void setShelfTimePeriod(Period shelfTimePeriod) {
		this.shelfTimePeriod = shelfTimePeriod;
	}
	
	public ShelfTimeReportDTO(int productUniqueId, int retailerid, String retailerName, byte productCategoryNumber,
			String productCategoryName, String productName, LocalDate productRecieveTimeStamp,
			LocalDate productSaleTimeStamp, Period shelfTimePeriod) {
		super();
		this.productUniqueId = productUniqueId;
		this.retailerid = retailerid;
		this.retailerName = retailerName;
		this.productCategoryNumber = productCategoryNumber;
		this.productCategoryName = productCategoryName;
		this.productName = productName;
		this.productRecieveTimeStamp = productRecieveTimeStamp;
		this.productSaleTimeStamp = productSaleTimeStamp;
		this.shelfTimePeriod = shelfTimePeriod;
	}
	public ShelfTimeReportDTO() {
		super();
	}
	@Override
	public String toString() {
		return "ShelfTimeReportDTO [productUniqueId=" + productUniqueId + ", retailerid=" + retailerid
				+ ", retailerName=" + retailerName + ", productCategoryNumber=" + productCategoryNumber
				+ ", productCategoryName=" + productCategoryName + ", productName=" + productName
				+ ", productRecieveTimeStamp=" + productRecieveTimeStamp + ", productSaleTimeStamp="
				+ productSaleTimeStamp + ", shelfTimePeriod=" + shelfTimePeriod + "]";
	}
	
	
	
}
