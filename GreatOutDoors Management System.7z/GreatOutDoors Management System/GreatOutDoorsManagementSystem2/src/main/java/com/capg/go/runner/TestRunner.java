package com.capg.go.runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="Feature/ShelfTimeReport.feature",glue={"com.capg.go.stepdefinition"},monochrome=true)
public class TestRunner {

}
