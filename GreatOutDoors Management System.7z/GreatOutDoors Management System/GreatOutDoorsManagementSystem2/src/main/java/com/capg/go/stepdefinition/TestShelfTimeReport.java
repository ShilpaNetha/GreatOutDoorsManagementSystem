package com.capg.go.stepdefinition;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestShelfTimeReport 
{
	WebDriver driver;
	@Given("^Admin is on GreatOutDoorsManagement System$")
	public void admin_is_on_Great_Out_Doors_Management_System() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Mallika Raghuram\\Downloads\\.cache\\selenium\\chromedriver\\win32\\85.0.4183.87\\chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.get("http://localhost:4200");
		   driver.manage().window().maximize();
		}
		
	 


	@When("^Admin clicks on Add Product Details")
	public void Admin_clicks_on_Add_Product_Details() throws Throwable 
	{		  
	    driver.findElement(By.xpath("/html/body/app-root/div/nav/ul/li[1]/a")).click();
	    driver.findElement(By.xpath("//*[@id=\"productUniqueId\"]")).sendKeys("2407");
	    driver.findElement(By.xpath("//*[@id=\"retailerid\"]")).sendKeys("2");
	    driver.findElement(By.xpath("//*[@id=\"retailerName\"]")).sendKeys("ShilpaNetha");
	    driver.findElement(By.xpath("//*[@id=\"productCategoryNumber\"]")).sendKeys("1");
	    driver.findElement(By.xpath("//*[@id=\"productCategoryName\"]")).sendKeys("Personal");
	    driver.findElement(By.xpath("//*[@id=\"productName\"]")).sendKeys("Laptop");
	    driver.findElement(By.xpath("//*[@id=\"productRecieveTimeStamp\"]")).sendKeys("23-05-2020");
	    driver.findElement(By.xpath("//*[@id=\"productSaleTimeStamp\"]")).sendKeys("15-09-2020");
	    driver.findElement(By.xpath("\"/html/body/app-root/app-updatereceivetime/div/form/input")).click();
	    Thread.sleep(3000);
	    Alert alert = driver.switchTo().alert();
	    alert.accept();
	    alert.accept();
	}

	@Then("^add details$")
	public void add_details() throws Throwable {
		//driver.navigate().refresh();
	   //driver.navigate().to("http://localhost:4200");
	   //System.out.println("New Booking is added successfully");
	}

	@When("^admin clicks on get retailer list$")
	public void admin_clicks_on_get_retailer_list() throws Throwable {
		 driver.findElement(By.xpath("/html/body/app-root/div/nav/ul/li[2]/a")).click();
	    System.out.println();
	}

	@Then("^the retailerList will be displayed$")
	public void the_retailerdetails_will_be_displayed() throws Throwable {
		driver.navigate().refresh();
	}



}
